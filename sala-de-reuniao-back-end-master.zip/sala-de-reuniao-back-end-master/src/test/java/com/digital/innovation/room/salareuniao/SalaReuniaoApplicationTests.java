package com.digital.innovation.room.salareuniao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalaReuniaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
